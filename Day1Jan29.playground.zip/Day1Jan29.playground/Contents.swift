//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
print(str)
var str1="Hiee!!!! this is my first swift program";
print(str1)


//use terminator for terminating the line..... by default it is new line
print("This is my string: \(str)",terminator:"......")

//use separator for for separating the multiple prompts
print("1","2","3","4","5",separator:"\t")
var n1 = 10
print("Number 1 :",n1,"String :",str)
var n2 = 20
var sum = n1 + n2
print("SUM is:",sum)
print("Sum is:",n1+n2)

/* type casting error as n1 is declared as an integer value so later on it can't be assigned a string value
n1="test"
print("n1:",n1)
*/
// declaring 'a' as an integer
var a:Int=50
print("a is",a)
var b:Float = 8346.36
print("b is",b)
var c:Double=23756775673.8946
print("c is",c)


//ctrl+cmd +space for getting emojis on mac
//ctrl +windows +space for getting emojis on windows
var emoji="🤔"
print("what's you thinking???",emoji)


// declaration using let is constant
let pi=3.14
//pi=23.3
print("Pi=",pi)


// having optional values
let myNum:Int? //optional
myNum=56
if myNum != nil {
    print("myNum:",myNum!) //declared as optional, need to unwrap the mynum using !
}
else {
    print("myNum is nil")
}

//optional values
//when string is converted to int : it is nil
let possiblenumber = "j:/hju" //"hello"
let convertednumber:Int?
convertednumber = Int(possiblenumber)
if convertednumber != nil {
    print("Converted number:",convertednumber!)
}
else {
    print("Converted number is nil")
}

//for loop
for i in 1..<10{
print("i = ",i)
}
//array values in string names languages use [] to declare array
let languages:[String]
languages = ["English","Spanish","French"]
for i in languages{
    print("languages : ",i)
}
let age : [Int]
age = [23,56,78,12,32,21,22]
var sum1=0

for i in age{
    print("Ages are:",i)
}

// _ is use if we don't want to declare any variable it saves memory
var answer:Int = 1
for _ in 1...5{
    answer *= 5;
    }
print("answer is :",answer)
// stride function is used to
var interval:Int=5
for i in stride(from: 00,to: 50, by: interval){
    print(i,"",terminator: "..")
}
print("\n")
//while
var j=1
while (j < 5) {
    print("Value of j is \(j)")
    j=j+1
}
//repeat while
j=5
repeat{
    print("Repeat : ",j )
j=j+2
}while(j<=10)
print("\n")

//Task
var number=6
if number<10 {
  for i in 1...10
  {
    a=i*5
    print(a)
    }
}
else if number>10{
    var fact=1
    for i in 1...5{
        fact=fact*i
    }
    print(fact)
}

//switch case
var num1 = 100
switch num1 {
case 100:
    print("Value of num is 100")
    fallthrough
case 10,15:
    print("Value of num is 10 or 15")
case 5:
    print("Value of num is 5")
default :
    print("default case")
    
}
