//: Playground - noun: a place where people can play
import UIKit
//Classes and Structure
//declaring a structure
struct project
{
    var title = ""
    var hours = 0
    
    func display()
    {
        print("Project is :",title)
        print("Total working hours required: ",hours)
    }
}
//DECLARING INSTANCE OF STRUCTURE
var LMSproject = project(title: "MOODLE" , hours:200)
print(LMSproject)

LMSproject.display()
LMSproject.hours = 300
LMSproject.display()

//Declaring a class
class Manager {
    var name : String = ""
    var productOwner : Bool = true
    var currentProjects = project()
}
//creating instance of class
let mgrCanada = Manager()
mgrCanada.name = "Kiran"
mgrCanada.productOwner = true
mgrCanada.currentProjects = project(title: "Sales representative",hours: 20)
print("mgrCanada Name: ",mgrCanada.name)
print("mgrCanada product Owner: ",mgrCanada.productOwner)
print("mgrCanada current project title : ",mgrCanada.currentProjects.title)
print("mgrCanada project hours : ",mgrCanada.currentProjects.hours)
mgrCanada.currentProjects = project(title: "Representative",hours: 500)
//we can update the values
print("mgrCanada Name: ",mgrCanada.name)
print("mgrCanada product Owner: ",mgrCanada.productOwner)
print("mgrCanada current project title : ",mgrCanada.currentProjects.title)
print("mgrCanada project hours : ",mgrCanada.currentProjects.hours)

//Structures are value types
struct address {
    var street = "265 Yorkland Blvd"
    var city = "Toronto"
    var postalCode = "M1H1Y1"
 }
var lambton = address()
print("Lambton : ",lambton)
var cestar = lambton           //let cestar will cause an error
print("Cestar : ",cestar)
//upadation only in cestar
cestar.street = "271 yorkland Blvd "
print("Cestar : ",cestar)
print("Lambton : ",lambton)

/*
 structures can't be compared
 if lambton == cestar {
    print("Lambton and Cestar are same")
}
else{
    print("Lambton and Cestar are not same")
}*/
//Classes are reference types
class Institute{
    var street = "265 Yorkland Blvd"
    var city = "Toronto"
    var postalCode = "M1H1Y1"
}
var myLambton = Institute()
print("Lambton : ",myLambton.street)
print(myLambton.city)
print(myLambton.postalCode)
var myCestar = myLambton
print("Cestar  :",myCestar.street)
print(myCestar.city)
print(myCestar.postalCode)
//updation in both the instances
myCestar.street = "271 yorkland Blvd "
print("Cestar  :",myCestar.street)
print(myCestar.city)
print(myCestar.postalCode)
print("Lambton : ",myLambton.street)
print(myLambton.city)
print(myLambton.postalCode)

//identical to ===
if myLambton === myCestar {
print("Lambton and Cestar are same")
}
else{
print("Lambton and Cestar are not same")
}
var yourCestar = Institute()
if yourCestar === myCestar {
    print("yourCestar and myCestar are same")
}
else{
print("yourCestar and myCestar are not same")
}









