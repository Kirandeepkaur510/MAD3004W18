//: Playground - noun: a place where people can play

import UIKit
struct address
{
  var street = "271 Yorklan Blvd"
  var area = "Toroto"
  var postalCode = "M1Y2H2"
}
class Person {
    var firstname = ""
    var lastname = ""
    var age = ""
    var address1 = address()
    var total_amount = ""
}
let P1 = Person()
P1.firstname = "Kirandeep"
P1.lastname = "Kaur"
P1.age = "21"
P1.address1 = address()
P1.total_amount = "4000"
print("First Name is : ",P1.firstname)
print("Last Name is : ",P1.lastname)
print("Age is : ",P1.age)
print("Street is : ",P1.address1.street)
print("Area is : ",P1.address1.area)
print("Postal Code is : ",P1.address1.postalCode)
print("Total amount is : ",P1.total_amount)
