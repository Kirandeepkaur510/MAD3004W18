//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
//for printing a paragraph use 3 qoutes
let strOne="""
This is first line
This is second line
This is one more line
Enough.....
"""
print(strOne)

//checking whether the string is rmpty or not
//using unicodes
var mood=""
let heart="\u{1F496}"
let face="\u{1F60D}"
mood="Happy"
if mood.isEmpty {
    print("Cheeer up")
}
else {
    print(heart)
    print(face)
}
//mood +="cheerful joyful"
print(mood)
//heart += "Be happy"

var firstname = String()
firstname = "Kirandeep"
print(firstname)
//
for i in firstname{
    print(i)
}
//Adding a character to the string
let initial : Character = "j"
firstname.append(initial)
print(firstname)
//counting the length of string
print("Firstname is :- \(firstname) which is \(firstname.count) character long")
//other way of concatenation
let str1 = "What uh want? "
let str2 = "Wanna sleep "
var str3 = str1 + str2
print(str3)
var reply = "Enjoy"
str3 += reply
print(str3)

//printing the characters by the help of their index
//end index is null
print("start Index:",firstname[firstname.startIndex])
print("before End Index:",firstname[firstname.index(before: firstname.endIndex)])
print("after start Index:",firstname[firstname.index(after: firstname.startIndex)])
print("5 th character:",firstname[firstname.index(firstname.startIndex,offsetBy: 4)])
print("3 th character from last:",firstname[firstname.index(firstname.endIndex,offsetBy: -3)])

//count the string, using for loop and index print the string in forward and reverse order
var task="Sun rises in the east"
var count = 0
print("String is :- \(task) which is \(task.count) character long")
for count in task {
    print(count)
}

//
var idx = firstname.index(firstname.startIndex,offsetBy: 3)
print("fourth character:",firstname[idx])

var language = "Swift"
print("language :",language)

//inserting at the end of string
language.insert("!",at: language.endIndex)
print("language :",language)

//inserting at the end of string
language.insert(contentsOf:" JAVA",at: language.endIndex)
print("language :",language)

//inserting in between
language.insert(contentsOf:" is nice than",at: language.index(language.startIndex,offsetBy: 6))
print("language :",language)

//remove string from the end
language.remove(at: language.index(before: language.endIndex))
print("language :",language)

//removing a subrange
let range = language.startIndex..<language.endIndex
language.removeSubrange(range)
print("language subrange removed:",language)
//printing till a particular value
let greeting = "Hello, world!"
let index = greeting.index(of: ",") ?? greeting.endIndex
let beginning = greeting[..<index]
let newString = String(beginning)
print(newString)

//String in upper case
print("String in upper case: ",newString.uppercased())

if (newString == newString.uppercased()) {
    print("EQUAL")
}
else{
    print("NOT EQUAL")
}

//Assigning the grade if it is empty
var grade : String?
//grade = "A"
let finalGrade = grade ?? "f" //? is used for optional value
if (finalGrade.isEmpty){
    print("Not graded yet")
}
else {
    print("Grade is:",finalGrade)
}

