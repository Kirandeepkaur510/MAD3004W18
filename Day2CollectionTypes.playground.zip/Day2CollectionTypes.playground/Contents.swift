//: Playground - noun: a place where people can play

import UIKit

//Array Declaration
var a = [10,20,30,40,50]
print("a[0]: \(a[0])")
print("a : ",a)

let j1=[32,54]
print("j1: ",j1)

//use methods to add values
var b = [Int]();
print("Size of Array b : \(b.count)")
b.append(100)
print("b[0] : \(b[0])")

b[0] = 1000
print("b[0] : \(b[0])")

//Error because of the limited size
//b[2] = 500
//print("b: ",b)
print("Size of array b : \(b.count)")

//assigning the default value
var num1 = [Int](repeating: 1,count: 3)
print("num1 array : \(num1)")
var num2 = [Int](repeating: 5,count: 3)
print("num2 array : \(num2)")

//Merging both the values
var numMerge = num1 + num2
print("numMerge array is : \(numMerge)")

