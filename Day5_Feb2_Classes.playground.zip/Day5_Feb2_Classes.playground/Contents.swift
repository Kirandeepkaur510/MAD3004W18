//: Playground - noun: a place where people can play

import UIKit

//Classes
class Employee{
    var empID: Int?
    var emp_name : String?
    var basicPay : Double?
    
    //initializers same as constructors
    //simple initializer
    init()
    {
        self.empID = 0
        self.emp_name = ""
        self.basicPay = 0.0
    }
    //parameterized intializer to assign values
    init(ID : Int,nm : String , pay : Double){
        self.empID = ID
        self.emp_name = nm
        self.basicPay = pay
    }
    
    //Deinitializer
    deinit{
        print("hjkhk")
    }
    func display(){
        print("EmployeeID : ",self.empID!) // self keyword is usedto show that the variable of this class is referred
        print("Name : ",self.emp_name!)
        print("Basic Pay : ",self.basicPay!)
    }
}
var emp1 = Employee()
emp1.empID = 101
emp1.emp_name = "Kirandeep"
emp1.basicPay = 2000
emp1.display()

//Inherited class
//whenever uh use init in subclass always use super.init in that
//Multiple inheritance is not supported in this
//in java interfaces are the solution for that but in swift we have protocols
class PermanentEmployee : Employee{
    var vacationWeeks : Int?
    
    //default initializer
    override init(){
        super.init()
        self.vacationWeeks = 0
    }
    //parameterized initializer of subclass
    init(eID : Int,enm : String , epay : Double , ev : Int){
        super.init(ID : eID, nm : enm , pay : epay)
        self.vacationWeeks = ev
    }
    
    override func display() { // function override error if we dont use override keyword
    super.display() //super keyword is used to access the variables of super class in here for permanent employee
    print("Vacation Weeks : ",self.vacationWeeks!)
    }
}
var obj2 = PermanentEmployee()
obj2.vacationWeeks = 10
obj2.empID = 102
obj2.emp_name = "Harry"
obj2.basicPay = 1500
print("__*__*__*__*__*__*__")
obj2.display()

//initialiazer assigns the value to these
var emp2 = Employee()
print("__*__*__*__*__*__*__")
emp2.display()

//another method of passing values as paramteer
var emp3 = Employee(ID : 103, nm : "Naveen" , pay : 3000)
print("__*__*__*__*__*__*__")
emp3.display()

//showing error in displaying the 4 th variable bcoz it is not initialised
var obj3 = PermanentEmployee()
print("__*__*__*__*__*__*__")
obj3.display()

//object of parameterized init of sub class
var obj4 = PermanentEmployee(eID : 105 , enm :"Gurpreet" , epay : 2500 , ev : 2)
print("__*__*__*__*__*__*__")
obj4.display()



//payroll var final pay double if vacweeks>5 -> final pay =basic - 100
/*class Payroll : PermanentEmployee{
    var finalPay : Double{
        get{
            var vw = self.vacationWeeks!
            if vw > 5{
               return self.basicPay! - 100
            }
            else{
                return self.basicPay!
                
            }
        }
    }
}
 */
//multiple inheritance

class Payroll : PermanentEmployee{
    var finalPay : Double?
    override init(){
        super.init()
        self.finalPay = 0
    }
    
    override init(eID : Int,enm : String , epay : Double , ev : Int){
        super.init(eID : eID, enm : enm , epay : epay , ev : ev)
        self.finalPay = 0
        
            if (ev > 5){
                self.finalPay! = self.basicPay! - 100
            }
            else{
                self.finalPay! = self.basicPay!
        }}
        override func display() {
            super.display()
            print("Final Pay : ",self.finalPay!)
        }
    
}
    var emp7 = Payroll(eID : 189,enm : "fghf" , epay : 4009 , ev : 12)
print("__*__*__*__*__*__*__")
    emp7.display()



//manipulate object array
var janPayroll = [Payroll]() //[Payroll]() by this multiple instances are created
let noOfEmployees = 2

for i in 0..<2 {
    janPayroll.append(Payroll(eID: 101, enm: "Kiran", epay: 1234, ev: 9))
    print("__*__*__*__*__*__*__")
    janPayroll[i].display()
}









