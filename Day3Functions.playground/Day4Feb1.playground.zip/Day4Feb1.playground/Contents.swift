//: Playground - noun: a place where people can play

import UIKit

//Closures in Swift

//Sorted closure
var months = [3,5,7,8,1,9,12,2,6]
print(months.sorted())
/* syntax of closure
{
  (parameters) -> return type in
    return statement
}
*/


//reverse function is used to perform the sorting in decreasing order ..comparison results in boolean result true or false
func reverse(_ s1: Int, _ s2:Int) -> Bool{
    return s1 > s2
}
//reverse closure is paassed by the sorted function
var reverseMonths = months.sorted(by: reverse)
print("REVERSED MONTHS:",reverseMonths)
// sorting by default is in increasing order
func increasing(_ s1:Int, _ s2:Int) -> Bool
{
    return s1 < s2
}
var increasingMonths = months.sorted(by: increasing)
print("INCREASING MONTHS:",increasingMonths)

//reverse Closure
var reverseClosure = months.sorted(by: {
    (s1: Int, s2: Int) -> Bool in
    return s1 > s2
})
print("Reverse Closure:",reverseClosure)

//inferrring parameter types from context
var inferTypes = months.sorted(by: {
    //(s1, s2) in return s1 < s2
    (s1, s2) in s1 < s2 //implicit return
})
print("Infer Types:",inferTypes)

//shorthand argument names
//$0 is the current element
print("Shorthand argument : ", months.sorted(by: {$0 < $1}))

//operator methods
print("Operator Methods : ", months.sorted(by: <))

//we are creating other closures
var three = [3,5,7,8,12,56]
print("Three : ", three)

var modThree = three.filter({ $0 % 3 == 0})
print("MOD Three : ", modThree)

var even = three.filter({ $0 % 2 == 0})
print("Even numbers : ", even)

var odd = three.filter({ $0 % 2 != 0})
print("Odd numbers : ", odd)


//nested functions closure
func makeIncrementer(forIncrement amount: Int) -> () -> Int{ // return function prototype
    var runningTotal = 0
    
    func incrementer() -> Int {
        runningTotal += amount
        return runningTotal
    }
return incrementer //function is returned
}
//function calls
let incrementByTen = makeIncrementer(forIncrement: 10)
print("First Call",incrementByTen())
print("Second Call",incrementByTen())
print("Third Call",incrementByTen())

let incrementBySeven = makeIncrementer(forIncrement: 7)
print("Increment by seven 1:",incrementBySeven())
print("Increment by seven 2:",incrementBySeven())
print("Increment by seven 3:",incrementBySeven())

print("Fourth Call",incrementByTen())

//Closures are references types
let incrementBySevenAgain = incrementBySeven
print("Increment by seven 4:",incrementBySevenAgain())

//An autoclosure is a closure that is automatically created to wrap an expression that’s being passed as an argument to a function.
//Auto Closures delays the evaluation
var errorList = [404,434,489,455,440]
print("Total Errors : ",errorList.count)

let debugger = { errorList.remove(at: 0) }
print("Total errors : ",errorList.count)

print("Now Solving \(debugger())! ") //a function with no parameters that returns a string
print("Total Errors : ",errorList.count)
print("Error List : ",errorList)

/*
 
 */
//You get the same behavior of delayed evaluation when you pass a closure as an argument to a function.
func solve(error debugger: @autoclosure () -> Int){
    print("Now Solving \(debugger())!")
}
solve(error: errorList.remove(at: 0))
print("errorList: ",errorList)


//escaping Closure
//A closure is said to escape a function when the closure is passed as an argument to the function, but is called after the function returns
var completionHandlers: [() -> Void] = []

func someFunctionWithEscapingClosure(completionHandler: @escaping () -> Void) {
    completionHandlers.append(completionHandler)
}
func someFunctionWithNonescapingClosure(closure: () -> Void) {
    closure()
}

class SomeClass {
    var x = 10
    func doSomething() {
        someFunctionWithEscapingClosure { self.x = 100 }
        someFunctionWithNonescapingClosure { x = 200 }
    }
}

let instance = SomeClass()
instance.doSomething()
print(instance.x)
// Prints "200"

completionHandlers.first?()
print(instance.x)
